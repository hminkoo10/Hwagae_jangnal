"""Run from the cloned repository, or pass --repo its path. Uses only Python stdlib."""
import argparse, hashlib, json, pathlib, subprocess, sys
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--repo", type=pathlib.Path, default=pathlib.Path.cwd())
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parent
repo = args.repo.resolve()
if not (repo / "ml/evaluate.py").is_file():
    parser.error("Run from the repository root or pass --repo PATH")
manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
for item in manifest["files"]:
    path = root / item["path"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
        raise SystemExit("Input SHA-256 mismatch: " + item["path"])
command = [sys.executable, "-m", "ml.evaluate", "--predictions", str(root / "current/test_predictions.csv"),
           "--sales", str(root / "train.csv.zip"), "--no-weather-predictions", str(root / "no-weather/test_predictions.csv"),
           "--output-dir", str(root / "recomputed"), "--check-against", str(root / "reference-metrics.csv")]
raise SystemExit(subprocess.call(command, cwd=repo))
